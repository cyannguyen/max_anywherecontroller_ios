./org.test.plugins.dummyplugin/src/ios/SourceWithFramework.m
