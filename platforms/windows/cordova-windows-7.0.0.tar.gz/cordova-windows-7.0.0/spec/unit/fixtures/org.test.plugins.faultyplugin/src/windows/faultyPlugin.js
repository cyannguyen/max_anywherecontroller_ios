./org.test.plugins.faultyplugin/src/windows8/faultyPlugin.js
