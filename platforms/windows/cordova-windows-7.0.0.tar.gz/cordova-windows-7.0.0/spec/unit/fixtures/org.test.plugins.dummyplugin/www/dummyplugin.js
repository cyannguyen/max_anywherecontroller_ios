./org.test.plugins.dummyplugin/www/dummyplugin.js
