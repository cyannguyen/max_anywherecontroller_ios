./org.test.plugins.dummyplugin/src/windows8/dummer.js
